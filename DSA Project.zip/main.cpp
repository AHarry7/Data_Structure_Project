#include"FRS.h"
#include "dataList.h"
using namespace std;


int main()
{
	FRS h;
	char ch;
	do
	{
		system("color 3F");
		cout << endl << endl;
		cout << "\t\t      --------------------------------" << endl;
		cout << "\t\t      |           MAIN MENU          |" << endl;
		cout << "\t\t      |                              |" << endl;
		cout << "\t\t------------------------------------------" << endl;
		cout << "\t\t|                                        |" << endl;
		cout << "\t\t|           1.FRONT DESK                 |" << endl;
		cout << "\t\t|                                        |" << endl;
		cout << "\t\t|           2.INSTRUCTOR                 |" << endl;
		cout << "\t\t|                                        |" << endl;
		cout << "\t\t|           3.CLIENT                     |" << endl;
		cout << "\t\t|                                        |" << endl;
		cout << "\t\t|           4.EXIT                       |" << endl;
		cout << "\t\t|                                        |" << endl;
		cout << "\t\t------------------------------------------" << endl;
		cout << "\n\tPlease Select Your Option (1-3) \n\n \t : ";
		cin >> ch;
		cout << endl;
		switch (ch)
		{
		case '1':
		{
			string username = "Admin", uname;
			string pass1 = "Bahria", pass;
			int i = 0;
			do
			{
				char ps;
				system("cls");

				pass = "";
				cout << "\n\n\t\t-----------------LOGIN-MENU------------------\n";
				cout << "\n\tEnter username : ";
				cin >> uname;
				cout << "\n\tEnter password : ";
				ps = _getch();
				while (ps != 13) {// 13 is ascii code for enter button

					pass.push_back(ps);
					cout << "*";

					ps = _getch();
				}
				if (uname == username && pass == pass1)
				{
					cout << "\n\n\tLOGIN SUCCESSFULLY! ";
					_getch();
					system("cls");
					h.frontMenu();
				}
				else
				{
					system("cls");
					cout << "\n\t INVALID USERNAME OR PASSWORD! TRY AGAIN ";
					++i;
				}
			} while (uname != username && pass != pass1 && i < 3);
			break;
		}
		case '2':
			system("cls");
			h.instructorMenu();
			break;
		case '3':
			system("cls");
			h.clientMenu();
			break;
		case '4':
			exit(0);
		default:
			system("cls");
			cout << "\a";
		}
	} while (ch != 4);


	_getch();
}