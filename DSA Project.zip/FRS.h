#ifndef FRS_HEADER
#define FRS_HEADER
#include "dataList.h"
class FRS:public Datalist
{
private:
	Datalist* search();
public:
	Datalist* head;
	FRS();
	bool isEmpty();
	void createProfile();
	void searchProfile();
	void modify();
	void Delete();
	void display();
	void frontMenu();
	void save();
	void fileRecord();
	void deleteoldRecord();
	void dietPlans();
	void DisplayClient();
	void instructorMenu();
	void workoutPlan();
	void instructions();
	void clientMenu();
};

#endif