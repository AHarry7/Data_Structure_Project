#include "dataList.h"

Datalist::Datalist()
{
	diet = "Not assigned";
	workout = "Not assigned";
	message = "No instructions yet";
}