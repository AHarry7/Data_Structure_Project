#ifndef Datalist_HEADER
#define Datalist_HEADER
#include <string>
#include <fstream>
#include <conio.h>
#include <iostream>
using namespace std;
class Datalist
{
public:
	Datalist();
	string name, email, address;
	int age, id;
	float weight;
	float height;
	float BMI;
	string diet,workout,message;
	Datalist* next;
};
#endif
